package com.example.tarjeta_presentacion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
